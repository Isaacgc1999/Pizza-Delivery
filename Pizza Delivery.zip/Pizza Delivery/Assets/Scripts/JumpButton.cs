﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpButton : MonoBehaviour
{
    public CharacterController player;
    public float forceJump = 12;
    private Vector3 movePlayer;


    public void PlayerOptions()
    {
        Debug.Log("x");
        if (player.isGrounded)
        {
            Debug.Log("f");
            movePlayer.y = forceJump; //MOVEMOS AL JUGADOR HACIA ARRIBA DESDE LA COMPONENTE Y 
        }

    }
}

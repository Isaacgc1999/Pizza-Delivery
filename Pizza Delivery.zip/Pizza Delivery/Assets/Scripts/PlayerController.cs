﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    public float horizontalMove;
    public float verticalMove;
    public CharacterController player;
    public float vel;
    private float auxVel;
    private Vector3 playerInput; //VECTOR QUE ALMACENA EL INPUT DE NUESTRO PERSONAJE(EL CONTROL)

    public Camera mainCam;
    private Vector3 camFwd; //DIRECCION EN LA QUE MIRA LA CAMARA
    private Vector3 camRight;

    private Vector3 movePlayer;
    public float gravity = 9.8f;
    public float fallVel;

    public float forceJump;
    public bool isOnSlope = false;
    private Vector3 normalHit; //SITIO EN EL QUE EL JUGADOR ESTÉ CHOCANDO
    public float slideVel;
    public float slopeForceDown;
    private bool isJumping = false;
    

    void Start()
    {
        player = GetComponent<CharacterController>();
    }

    
    void Update()
    {
        float dt = Time.deltaTime;

        horizontalMove = Input.GetAxis("Horizontal");
        verticalMove = Input.GetAxis("Vertical");

        playerInput = new Vector3(verticalMove, 0, -horizontalMove);
        playerInput = Vector3.ClampMagnitude(playerInput, 1); //CERCAR PARA QUE HAYA UNA DISTANCIA MAXIMA ENTRE UN VALOR Y OTRO, EN ESTE CASO ENTRE EL JUGADOR Y 1

        camDirection();

        movePlayer = playerInput.x * camFwd + playerInput.z * -camRight; //MOVEMOS LA CÁMARA ACCEDIENDO A LOS COMPONENTES X Y Z DEL JUGADOR PARA QUE LA CÁMARA SE MUEVA RESPECTO A LO QUE DEFINIMOS SEGUN QUEREMOS( PARA QUE EL JUGADOR MIRE SIEMPRE A DONDE VA)

        movePlayer = movePlayer * vel; //AISLAMOS LA VELOCIDAD DE EL PLAYER.MOVE DEBIDO A QUE SINO EXISTEN PROBLEMAS DE VARIACIÓN DE VELOCIDAD, EN CAMBIO SI LA AISLAMOS SIEMPRE TENDRÁ EL MISMO VALOR.

        player.transform.LookAt(player.transform.position + movePlayer); //CADA VEZ QUE ACTUALICEMOS LA POSICIÓN EL JUGADOR MIRARÁ HACIA ESA DIRECCIÓN

        SetGravity();

        PlayerOptions();

        if(isJumping)
        {
            fallVel = forceJump; //UTILIZAMOS LA VARIABLE DE ANTES Y SE LA IGUALAMOS AL VALOR POSITIVO DE LA FUERZA DE SALTO

            movePlayer.y = fallVel; //MOVEMOS AL JUGADOR HACIA ARRIBA DESDE LA COMPONENTE Y 

            isJumping = false;
        }

        player.Move(movePlayer * dt);

        if(Input.GetKeyDown(KeyCode.LeftShift))
        {
            auxVel = vel; //IGUALAMOS LA VELOCIDAD A LA AUXILIAR PARA QUE LA VELOCIDAD A LA QUE IBAMOS ANTES NO SEA PERDIDA PARA LUEGO PODER RECUPERARLA AL QUITAR EL DEDO DEL SHIFT
            vel = vel + 10;
        }
        else if(Input.GetKeyUp(KeyCode.LeftShift))
        {
            vel = auxVel;
        }
    }

    private void camDirection()
    {
        camFwd = mainCam.transform.forward; //LA CAMARA MIRA HACIA DELANTE
        camRight = mainCam.transform.right; //LA CAMARA MIRA HACIA LA DERECHA

        camFwd.y = 0; //NO QUIERO QUE LA CAMARA GIRE EN EL EJE Y ASÍ QUE LA IGUALAMOS A 0 PARA QUE SOLO 
        camRight.y = 0; // SE PUEDA MIRAR HACIA IZQUIERDA Y DERECHA

        camFwd = camFwd.normalized; //VALOR NORMALIZADO DE LOS VECTORES PARA QUE TENGAMOS UNA DIRECCIÓN MÁS AJUSTADA.
        camRight = camRight.normalized;
    }

    private void SetGravity()
    {
        if(player.isGrounded)
        {
            fallVel = -gravity * Time.deltaTime; //LA GRAVEDAD VA CON MENOS PORQUE DEFINIMOS EN VALOR POSITIVO LA GRAVEDADW
            movePlayer.y = fallVel; // COMO ESTÁ EN EL SUELO ÚNICAMENTE SE LE ASIGNA LA GRAVEDAD A LA Y PERO NO SE LE RESTA
        }
        else
        {
            fallVel -= gravity * Time.deltaTime; //LE QUITAREMOS EL VALOR DE LA GRAVEDAD A LA COMPONENTE Y DEL PERSONAJE CADA VEZ QUE ESTÉ EN EL AIRE SIEMPRE Y CUANDO ESTÉ EN EL AIRE Y NO EN EL SUELO
            movePlayer.y = fallVel;
        }

        slideDownTheEdge();
    }

    public void PlayerOptions()
    {
        if(Input.GetButtonDown("Jump")) 
        {
            Jump();
        }

    }

    public void Jump()
    {
        Debug.Log("x" + Time.deltaTime);
        
        if (player.isGrounded)
        {
            isJumping = true;
        }
    }

    public void slideDownTheEdge()
    {
        isOnSlope = Vector3.Angle(Vector3.up, normalHit) >= player.slopeLimit; //DETECTAMOS QUE ESTAMOS EN UNA RAMPA(EL ANGULO ES MAYOR O IGUAL AL ANGULO MÁXIMO QUE INDICAMOS QUE HA DE TENER LA RAMPA(SLOPELIMIT))
        //EL ANGULO ENTRE EL VECTOR HACIA ARRIBA Y LA NORMAL HA DE SER MAYOR O IGUAL A EL ANGULO MÁXIMO QUE PODEMOS SUBIR(PARA QUE SEA TAN EMPINADO QUE NO LO PODAMOS SUBIR PERO SÍ RESBALARNOS)
        if(isOnSlope)
        {
            movePlayer.x += ((1f - normalHit.y) * normalHit.x) * slideVel; //SIEMPRE QUE EL ANGULO SEA MAYOR O IGUAL AL MAXIMO, DESLIZAREMOS AL PERSONAJE
            movePlayer.z += ((1f - normalHit.y) * normalHit.z) * slideVel; //MOVEMOS LO QUE SE ESTÁ MOVIENDO MAS  LA NORMAL DE LA X POR LA VELOCIDAD A LA QUE QUEREMOS DESLIZARNOS
            //PARA HACER QUE LAS RAMPAS MÁS EMPINADAS HAGAN QUE NUESTRO PERSONAJE SE DESLICE MÁS RÁPIDO, DEPENDIENDO DE LA Y DE LA RAMPA, LA VELOCIDAD DE X Y DE Z SERÁ MAYOR

            //movePlayer.y += slopeForceDown; //LE APLICAMOS TAMBIÉN UNA FUERZA EN Y PARA QUE NO HAYA SALTOS, PORQUE NOSOTROS MOVEMOS HACIA DELANTE O HACIA AL LADO Y NO HACIA ABAJO.
        }
    }

    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        normalHit = hit.normal; //DETECTA CUANDO NUESTRO PERSONAJE CHOCA CON ALGO(NO CUANDO ALGO TOCA CON NOSOTROS)

    }
}

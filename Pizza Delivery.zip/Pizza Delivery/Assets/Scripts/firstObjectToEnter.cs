﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class firstObjectToEnter : MonoBehaviour
{

    [SerializeField] private Text firstObjectInBox; //SERIALIZEFIELD LO QUE HACE ES QUE AUNQUE ES UNA VARIABLE PRIVADA QUE NO PUEDEN ACCEDER LOS OTROS SCRIPTS Y CLASES, SE MUESTRE EN EL EDITOR PARA QUE SE LE PUEDA ASIGNAR UN TEXTO EN ESTE CASO
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "pickableObject")
        {
            firstObjectInBox.enabled = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "pickableObject")
        {
            firstObjectInBox.enabled = false;
        }
    }
}

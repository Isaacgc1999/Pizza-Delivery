﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickUpObject : MonoBehaviour
{
    public GameObject objectToPickUp;
    private GameObject pickedObject;
    public Transform interactionArea;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))  //SI EL OBJETO NO ES NULL Y EL OBJETO SE PUEDE COGER Y NO TENEMOS NINGUN OBJETO COGIDO, EJECUTAMOS LA ACCIÓN
        {
            Grab();
            pickedObject.GetComponent<Rigidbody>().AddForce(transform.forward);
        }
    }

    public void Grab()
    {
        if (objectToPickUp != null && objectToPickUp.GetComponent<PickableObject>().isPickable == true && pickedObject == null)
        {

            pickedObject = objectToPickUp; //ASIGNAMOS AL OBJETO QUE HEMOS COGIDO LA VARIABLE DE QUE HA SIDO COGIDO
            pickedObject.GetComponent<PickableObject>().isPickable = false; //LE DECIMOS QUE EL OBJETO YA NO SE PUEDE COGER PORQUE LO TENEMOS YA COGIDO
            pickedObject.transform.SetParent(interactionArea);//HACEMOS HIJO AL OBJETO DE LA ZONA DE NUESTRAS "MANOS" EN LA QUE PODEMOS COGER COSAS

            pickedObject.transform.position = interactionArea.position;//REFRESCAMOS EN CADA FRAME LA POSICIÓN DEL OBJETO CON LA POSICIÓN DEL AREA DE COGER COSAS
            pickedObject.GetComponent<Rigidbody>().useGravity = false;//LE DECIMOS AL OBJETO QUE NO USE GRAVEDAD PARA QUE NO SE NOS CAIGA
            pickedObject.GetComponent<Rigidbody>().isKinematic = true;//LE DECIMOS QUE ES KINEMÁTICO PARA QUE NO LE AFECTEN LAS FÍSICAS Y AL ENTRAR EN CONTACTO CON NOSOTROS NO SALGA VOLANDO
        }

        else if (pickedObject != null) //SIEMPRE QUE TENGAMOS OBJETO EN LA MANO SE EJECUTARÁ LA ACCIÓN
        {
            pickedObject.GetComponent<PickableObject>().isPickable = true; //AL SOLTARLO HACEMOS QUE EL OBJETO PUEDA VOLVERSE A HACER COGIBLE
            pickedObject.transform.SetParent(null); //LO QUITAMOS DE HIJO DE LA ZONA DE INTERACCIÓN

            pickedObject.GetComponent<Rigidbody>().useGravity = true; //LE DEVOLVEMOS LA GRAVEDAD
            pickedObject.GetComponent<Rigidbody>().isKinematic = false; //LE DECIMOS QUE YA NO ES KINEMÁTICO PARA QUE LE AFECTEN LAS FUERZAS
            pickedObject.GetComponent<Rigidbody>().AddForce(transform.forward * 2);
            pickedObject = null; //LE ASIGNAMOS A NULL EL PICKEDOBJECT PARA QUE SE PUEDA VOLVER A COGER
        }
    }
}

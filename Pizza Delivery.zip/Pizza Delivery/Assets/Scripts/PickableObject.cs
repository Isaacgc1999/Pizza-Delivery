﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickableObject : MonoBehaviour
{
    public bool isPickable = true;

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "PlayerInteractionArea")
        {
            other.GetComponentInParent<PickUpObject>().objectToPickUp = this.gameObject; //CADA VEZ QUE ENTRE EN EL AREA DE INTERACCIÓN, ACCEDEREMOS AL SCRIPT DE PICKUPOBJECT PARA QUE LA VARIABLE OBJECTTOPICKUP SEPA QUÉ OBJETO TIENE EN LA ZONA
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if(other.tag == "PlayerInteractionArea")
        {
            other.GetComponentInParent<PickUpObject>().objectToPickUp = null; //CUANDO ESE OBJETO SALGA DE LA ZONA LE DECIMOS A LA MISMA VARIABLE QUE NO HAY NADA POR ESO SE LO ASIGNAMOS A NULL
        }
    }
}

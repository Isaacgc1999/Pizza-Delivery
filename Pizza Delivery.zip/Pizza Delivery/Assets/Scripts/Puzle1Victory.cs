﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Puzle1Victory : MonoBehaviour
{
    [SerializeField ]private Text winText;
    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Player")
        {
            winText.enabled = true; //HABILITAMOS O DESHABILITAMOS CANVAS EN FUNCIÓN SI EL JUGADOR SE ENCUENTRA COLISIONANDO CON EL TRIGGER QUE TENEMOS
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Player")
        {
            winText.enabled = false;
        }
    }
}

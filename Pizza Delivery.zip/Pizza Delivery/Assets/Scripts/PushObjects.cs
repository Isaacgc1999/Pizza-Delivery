﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PushObjects : MonoBehaviour
{
    public float pushPower;
    private float targetMass;

    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        Rigidbody rb = hit.collider.attachedRigidbody; //SIEMPRE Y CUANDO EL OBJETO CON EL QUE CHOQUEMOS TENGA UN RIGIDBODY, PODREMOS EMPUJARLO

        if (rb == null || rb.isKinematic) //SI EL OBJETO ES KINEMATICO NO LO PODREMOS EMPUJAR
        {
            return;
        }

        if(hit.moveDirection.y < -0.3) //SI CAEMOS ENCIMA DE UN OBJETO NO LO VAMOS A EMPUJAR POR EJEMPLO ENTONCES SI ESTAMOS CAYENDO Y CHOCAMOS NO HA DE MODIFICARSE LA FISICA
        {
            return;
        }

        targetMass = rb.mass; //ALMACENAMOS LA MASA QUE TIENE EL RIGIDBODY DEL OBJETO EN UNA VARIABLE QUE LUEGO UTILIZAMOS PARA QUE DEPENDIENDO DE LA MASA DEL OBJETO SEA MAS DIFICIL O MAS FACIL MOVERLO

        Vector3 pushDirection = new Vector3(hit.moveDirection.x, 0, hit.moveDirection.z); //DIRECCIÓN EN LA QUE ESTAMOS GOLPEANDO AL OBJETO

        rb.velocity = pushDirection * pushPower / targetMass; //LA VELOCIDAD DEL OBJETO SERÁ IGUAL A LA DIRECCIÓN QUE LE HEMOS DADO POR LA FUERZA QUE TIENE EL PERSONAJE
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public Vector3 offset;
    private Transform target;
    [Range (0,1)]public float lerpValue;
    public float sensibility;


    void Start()
    {
        target = GameObject.Find("Player").transform; //BUSCAMOS EL TRANSFORM DEL JUGADOR PARA QUE NO TENGAMOS QUE INSERTAR AL JUGADOR DESDE EL EDITOR Y INDEPENDIENTEMENTE DE QUE SE CAMBIE EL JUGADOR O SE AÑADAN MÁS JUGADORES, SE TENGA EN CUENTA EL TAG DEL JUGADOR
    }

    void LateUpdate() //HACEMOS QUE SEA LO ÚLTIMO QUE SE EJECUTE PARA QUE LA CÁMARA CAMBIE DESPUÉS DE HABER EFECTUADO EL MOVIMIENTO.
    {
        transform.position = Vector3.Lerp(transform.position, target.position + offset, lerpValue); //LERP LO QUE HACE ES MOVER LA POSICIÓN DE UN OBJETO DESDE UN VECTOR HACIA OTRO SUAVEMENTE(LERPVALUE SE UTILIZA PARA HACER QUE HAYA MAS O MENOS DELAY EN LA VELOCIDAD AL SEGUIR LA CAMARA)

        offset = Quaternion.AngleAxis(Input.GetAxis("Mouse X") * sensibility, Vector3.up) * offset; //EL OFFSET VARIA SEGUN EL RATÓN. QUEREMOS QUE GIRE X GRADOS SEGUN EL RATÓN Y LUEGO LE AÑADIMOS LA SUAVIDAD CON LA QUE GIRA.
        //UTILIZAMOS VECTOR.UP PORQUE ES LA Y Y QUEREMOS QUE GIRE AL REDEDOR DE ESE EJE(ES DECIR DE IZQUIERDA A DERECHA)
        transform.LookAt(target);  //FINALMENTE HACEMOS QUE MIRE AL JUGADOR PARA QUE NO SE PIERDA
    }
}
